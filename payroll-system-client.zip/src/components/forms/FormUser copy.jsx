import React from 'react';

export default function FormUser() {
  return (
    <>
      <form>
        <p>Aqui va el formulario</p>
      </form>
    </>
  );
};