export default function UserProfile() {
  return <h1>Perfil de Usuario</h1>;
}