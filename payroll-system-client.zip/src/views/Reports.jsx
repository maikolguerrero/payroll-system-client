export default function Reports() {
  return <h1>Reportes</h1>;
}