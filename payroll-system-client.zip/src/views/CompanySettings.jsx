export default function CompanySettings() {
  return <h1>Configuración de la Empresa</h1>;
}