export default function PerceptionsDeductions() {
  return <h1>Percepciones y Deducciones</h1>;
}